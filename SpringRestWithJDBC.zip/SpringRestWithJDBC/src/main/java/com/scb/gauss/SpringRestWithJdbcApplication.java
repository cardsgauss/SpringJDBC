package com.scb.gauss;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.scb.gauss.bean.Account;
import com.scb.gauss.service.AccountService;

@SpringBootApplication
public class SpringRestWithJdbcApplication {

	public static void main(String[] args) {
		
		ApplicationContext context=SpringApplication.run(SpringRestWithJdbcApplication.class, args);
		AccountService accService=context.getBean(AccountService.class);
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id:");
		int id=sc.nextInt();
		System.out.println("Enter type of account:");
		String type=sc.next();
		System.out.println("Enter Min Balance:");
		int min=sc.nextInt();
		Account accOne=new Account(id,type,min);
		Account accTwo=new Account(id,type,min);
		accService.createAccount(accOne);
		accService.getAllAccounts();
		accService.getAccountById(125);
		List<Account> accounts = new ArrayList<>();
		accounts.add(accOne);
		accounts.add(accTwo);
		accService.insertAccounts(accounts);
	}

}
